let screenV = "";
let screen = document.querySelector(".screen");
let screenR = false;
let operations = "";
let allOperations = document.querySelector(".all-operations");
let allOp = [];
let lastOperator = "";


function changeMode() {
    let calculator = document.getElementById("calculator")
    calculator.classList.toggle("dark-mode")
}

document.getElementById("zero").addEventListener("click", clickBtn);
document.getElementById("one").addEventListener("click", clickBtn);
document.getElementById("two").addEventListener("click", clickBtn);
document.getElementById("three").addEventListener("click", clickBtn);
document.getElementById("four").addEventListener("click", clickBtn);
document.getElementById("five").addEventListener("click", clickBtn);
document.getElementById("six").addEventListener("click", clickBtn);
document.getElementById("seven").addEventListener("click", clickBtn);
document.getElementById("eight").addEventListener("click", clickBtn);
document.getElementById("nine").addEventListener("click", clickBtn);

document.getElementById("sum").addEventListener("click", getOperator);
document.getElementById("minus").addEventListener("click", getOperator);
document.getElementById("multi").addEventListener("click", getOperator);
document.getElementById("division").addEventListener("click", getOperator);
document.getElementById("modulus").addEventListener("click", getOperator);
document.getElementById("coma").addEventListener("click", getOperator);
document.getElementById("pos_Neg").addEventListener("click", getSign);

document.getElementById("result").addEventListener("click", getOperator);
document.getElementById("reset").addEventListener("click", getReset);

function getAllOperations(event) {
    allOp.push(screen.value);
    allOp.push(event.target.getAttribute("operator"));
    //  console.log("equal: ", event.target.getAttribute("operator"));  
    allOperations.value = allOp.join(" ");


    if (event.target.getAttribute("operator") == "=") {
        allOp = [];
        allOperations.value = "";
    }
}

function clickBtn(event) {
    // Condition that returns true if value is 0, this is because the value 0 would persist on the left of our value (i.e. 0132)
    if (screen.value === "0") {
        screen.value = "";
    }
    if (screenR) {
        screen.value = event.target.value;
        screenR = false;
    } else {
        screen.value += event.target.value;
    }
    lastOperator = "";
    // console.log("exited clickBTN with sv:", screenV +" s:",screen.value);
}

// function getOperator(event) {
//   getAllOperations(event);
//   // console.log("Screen value before switch: ", screen.value+" screenV:", screenV);
//   if (screen.value == ".") {
//     screen.value = 0;
//   }
//     if(event.target.getAttribute("id") != lastOperator){
//     switch (event.target.getAttribute("id")) {
//       case "sum":
//         getSum(event);        
//         break;
//       case "minus":
//         getMinus(event);
//         break;
//       case "multi":
//         getMulti(event);
//         break;
//       case "division":
//         getDivision(event);
//         break;
//       case "modulus":
//         getMod(event);
//         break;
//         case "coma":
//           getDecimal(event);
//           break;
//         case "result":
//           getResult();
//           allOperations.value = "";         
//           break;
//       default:
//         break;
//     }
//   } 

//   lastOperator = event.target.getAttribute("id");  
//   // console.log("Last Operator:",lastOperator);
// }

function getOperator(event) {
    if (screen.value == ".") {
        screen.value = 0;
    }
    if (event.target.getAttribute("id") != lastOperator) {
        getAllOperations(event);
        switch (event.target.getAttribute("id")) {
            case "sum":
                getValues(event);
                operations = "sum";
                break;
            case "minus":
                getValues(event);
                operations = "minus";
                break;
            case "multi":
                getValues(event);
                operations = "multi";
                break;
            case "division":
                getValues(event);
                operations = "division";
                break;
            case "modulus":
                getValues(event);
                operations = "modulus";
                break;
            case "coma":
                getDecimal(event);
                break;
            case "result":
                getResult();
                allOperations.value = "";
                break;
            default:
                break;
        }
    }
    lastOperator = event.target.getAttribute("id");
    // console.log("Last Operator:",lastOperator);
}

function getValues(event) {
    if (operations !== "equal" && screenV != "" && screen.value != "") {
        getIntermedio();
    }
    if (screen.value != "") {
        screenV = screen.value;
        // console.log("Inside getValues screenV",screenV);
    }
    screen.value = "";
    screen.value += event.target.value;
    // console.log("Getting screen.value",screen.value);
}

// function getSum(event) {
//   // console.log("I have entered sum with sv:",screenV+" s:", screen.value);
//   if (operations !== "equal") {
//     getIntermedio();
//   }
//   operations = "sum";
//   if (screen.value != "") {
//     screenV = screen.value;
//   }
//   screen.value = "";
//   screen.value += event.target.value;
// }

// function getMinus(event) {
//   // console.log("I have entered minus with sv:",screenV+" s:", screen.value);
//   if (operations !== "equal") {
//     getIntermedio();
//   }
//   operations = "minus";
//   if (screen.value != "") {
//     screenV = screen.value;
//   }
//   screen.value = "";
//   screen.value += event.target.value;
// }

// function getMulti(event) {
//   // console.log("I have entered multi with sv:",screenV+" s:", screen.value);
//   if (operations !== "equal") {
//     getIntermedio();
//   }
//   operations = "multi";
//   if (screen.value != "") {
//     screenV = screen.value;
//   }
//   screen.value = "";
//   screen.value += event.target.value;
// }

// function getDivision(event) {
//   // console.log("I have entered sum with sv:",screenV+" s:", screen.value);
//   if (operations !== "equal") {
//     getIntermedio();
//   }
//   operations = "division";
//   if (screen.value != "") {
//     screenV = screen.value;
//   }
//   screen.value = "";
//   screen.value += event.target.value;
// }

// function getMod(event) {
//   console.log("I have entered sum with sv:",screenV+" s:", screen.value);
//   if (operations !== "equal") {
//     getIntermedio();
//   }
//   operations = "modulus";
//   if (screen.value != "") {
//     screenV = screen.value;
//   }
//   screen.value = "";
//   screen.value += event.target.value;
// }

function getSign(event) {
    screen.value = -screen.value;
}

function getReset() {
    screen.value = "0";
    screenV = 0;
    allOperations.value = "";
    allOp = [];
}

function getIntermedio() {
    getResult();
    screenR = false;
    // console.log("intermedio", screen.value);
}

function getDecimal(event) {
    if (screenR) {
        screen.value = "0.";
        screenR = false;
    } else
        screen.value += ".";
}

function getReset() {
    screen.value = "0";
    screenV = 0;
    allOperations.value = "";
    allOp = [];
}

function getResult() {
    // if (screen.value == "." || screen.value == "") screen.value = 0;
    switch (operations) {
        case "sum":
            console.log(screenV + " + " + screen.value);
            screen.value = parseFloat(screen.value) + parseFloat(screenV);
            break;
        case "minus":
            console.log(screenV + " - " + screen.value);
            screen.value = parseFloat(screenV) - parseFloat(screen.value);
            break;
        case "multi":
            console.log(screenV + " x " + screen.value);
            screen.value = parseFloat(screenV) * parseFloat(screen.value);
            break;
        case "division":
            console.log(screenV + " / " + screen.value);
            screen.value = parseFloat(screenV) / parseFloat(screen.value);
            break;
        case "modulus":
            console.log(screenV + " % " + screen.value);
            screen.value = parseFloat(screenV) % parseFloat(screen.value);
            break;
        default:
            break;
    }
    console.log("Result:", screen.value);
    screenR = true;
    operations = "equal";
}