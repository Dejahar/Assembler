# Assembler Institute: Create a calculator

## Introduction

Coding a real project is the best way to learn JavaScript, and a calculator is one of the best projects to start with. A calculator covers all the complex interactions with UI and JavaScript and is simple enough for any particular level you may have.

In this project you will learn to develop a calculator with two graphical styles: Light Mode & Dark Mode.

![Different display of the calculator depending on light/dark theme](/src/images/calculator01.jpg)

## What are the main objectives in this project?

- Improve your knowledge of **JavaScript**
- Learn to work with the **HTML DOM**
- Learn and improve your knowledge in logic processes
- How to sync JavaScript code with a UI
- The ways to handle user inputs
- How to debug errors 

## 1. General analysis

In this project you will have to develop a calculator in HTML, CSS, and JS. You will complete it using **VS Code**. The main goal is to peer-coding this pill using [Live Share](https://marketplace.visualstudio.com/items?itemName=MS-vsliveshare.vsliveshare) and [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) plugins to share the project in real time. Other platforms such as **Duckly extension** or **CodeSandbox**.

If using Live Share, one member (for each team) will be the host. The host will run the **Live Share plugin** and will share the project with the rest of the team.

Once all members of the team are in the shared repository, the host will display the **Live Server Plugin** on the **HTML** of the project. This will allow all members to have a browser window with the project being updated in real time, while allowing each team member to run the HTML page to execute the calculator declared in Javascript.

## 2. Develop a calculator

### Phase 1:

During the first phase, you will have to create the basic calculator with one visual mode (light mode)

**Rules**:

- The calculator has the main basic functions (see image)
- The calculator is capable of performing operations, returning the result and printing in the calculator screen

### Phase 2:

Create a dark mode. When using the light and dark mode switch the styles change without reloading the page. Yo can use the approach you consider appropriate to make this change

**Rules**:

- Add an operations log that you can later consult by console

### Phase 3:

**Rules**:

- Being able to use multiple operations simultaneously like ( 5 + 6 x 4 - 2 )
- Update the calculator interface to display the full operation

## 3. Deliverables

To evaluate the project you will need the following deliverables:

- Project files with a **.zip compressed folder**, that you will have to email to academics@assemblerschool.com.
- A **presentation in Google Slides** explaining:
  - What lessons you’ve learned during this project
  - How have you decided to organize the three stages of the app that you had to develop?

## 4. Resources

Onclick Event: https://www.w3schools.com/jsref/event_onclick.asp
