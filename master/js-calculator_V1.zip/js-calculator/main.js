document.getElementById("zero").addEventListener("click", clickBtn);
document.getElementById("one").addEventListener("click", clickBtn);
document.getElementById("two").addEventListener("click", clickBtn);
document.getElementById("three").addEventListener("click", clickBtn);
document.getElementById("four").addEventListener("click", clickBtn);
document.getElementById("five").addEventListener("click", clickBtn);
document.getElementById("six").addEventListener("click", clickBtn);
document.getElementById("seven").addEventListener("click", clickBtn);
document.getElementById("eight").addEventListener("click", clickBtn);
document.getElementById("nine").addEventListener("click", clickBtn);

document.getElementById("sum").addEventListener("click", getSum);
document.getElementById("minus").addEventListener("click", getMinus);
document.getElementById("multi").addEventListener("click", getMulti);
document.getElementById("division").addEventListener("click", getDivision);
document.getElementById("modulus").addEventListener("click", getMod);
document.getElementById("pos_Neg").addEventListener("click", getSign);
document.getElementById("coma").addEventListener("click", getDecimal);



document.getElementById("result").addEventListener("click", getResult);
document.getElementById("reset").addEventListener("click", getReset);

let screenV = "";
let screen = document.querySelector(".screen");
let screenR = false;

let operator = "";

function clickBtn(event) {
  // console.log(event.target.value);
  //   Condition that only returns true if the screen.value is a number(+ or -), replaces the screen.value with the new one
  //   if(screen.value !== 0) {
  //     screen.value = event.target.value;
  //   }
  //   else
  // Condition that returns true if value is 0, this is because the value 0 would persist on the left of our value (i.e. 0132)
  if (screen.value === "0") {
    screen.value = "";
  }
  if (screenR) {
    screen.value = event.target.value;
    screenR = false;
  } else {
    screen.value += event.target.value;
  }
}

function getSum(event) {
  operator = "sum";
  screenV = screen.value;
  screen.value = "";
  screen.value += event.target.value;
  
}

function getMinus(event) {
  operator = "minus";
  screenV = screen.value;
  screen.value = "";
  screen.value += event.target.value;
}

function getMulti(event) {
  operator = "multi";
  screenV = screen.value;
  screen.value = "";
  screen.value += event.target.value;
}

function getDivision(event) {
  operator = "division";
  screenV = screen.value;
  screen.value = "";
  screen.value += event.target.value;
}

function getMod(event) {
  operator = "modulus";
  screenV = screen.value;
  screen.value = "";
  screen.value += event.target.value;
}

function getSign(event) {
  screen.value = -screen.value; 
}

function getDecimal(event) {
  screen.value += ".";  
}

function getReset() {
  screen.value = 0;
}

function getResult() {
  switch (operator) {
    case "sum":
      console.log("Number A:",parseFloat(screen.value) + " Number B:",parseFloat(screenV))
      console.log("I am here");
      screen.value = parseFloat(screen.value) + parseFloat(screenV);
      screenR = true;
      break;
    case "minus":
      screen.value = parseFloat(screenV) - parseFloat(screen.value);
      screenR = true;
      break;
    case "multi":
      screen.value = parseFloat(screenV) * parseFloat(screen.value);
      screenR = true;
      break;
    case "division":
      screen.value = parseFloat(screenV) / parseFloat(screen.value);
      screenR = true;
      break;      
    case "modulus":
      screen.value = parseFloat(screenV) % parseFloat(screen.value);
      screenR = true;
      break;   
    default:
      break;
  }
}
// let number = parseInt(screenV)
