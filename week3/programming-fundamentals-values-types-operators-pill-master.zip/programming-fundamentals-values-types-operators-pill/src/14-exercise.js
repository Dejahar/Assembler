/**
 * Store in the variable result the length of the array numbers.
 *
 * NOTE:
 * You will have to learn how to read/access
 * the length property of an array to solve this exercise.
 */
function getArrLength() {
  // Add your code here
  let numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  let result;

  // Add your code here

  // Don’t change this code
  return result;
}

export default getArrLength;
