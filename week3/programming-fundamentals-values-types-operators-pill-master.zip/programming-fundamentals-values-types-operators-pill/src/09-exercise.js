/**
 * Save in the variable 'division' the result of
 * dividing the variable 'a' by the variable 'b':
 * a / b
 */
function divide() {
  let a = 20;
  let b = 10;
  let division;

  // Add your code here

  // Don’t change this code
  return division;
}

export default divide;
