/**
 * Create an array of strings with the following days of the week.
 *
 * Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
 */
function weekDays() {
  // Add your code here
  let days = [];

  // Don’t change this code
  return days;
}

export default weekDays;
