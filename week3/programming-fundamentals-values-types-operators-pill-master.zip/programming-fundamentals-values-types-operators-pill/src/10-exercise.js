/**
 * Save in the variable 'multiplication' the result of
 * multiplying the variable 'a' by the variable 'b' :
 * a * b
 */
function multiply() {
  let a = 20;
  let b = 10;
  let multiplication;

  // Add your code here

  // Don’t change this code
  return multiplication;
}

export default multiply;
