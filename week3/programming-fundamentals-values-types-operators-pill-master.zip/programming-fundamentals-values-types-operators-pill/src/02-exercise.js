/**
 * Create a variable
 * named: myNumber
 *
 * that stores any number
 */
function makeNumber() {
  // Write your code here

  // Don’t change this code
  return myNumber;
}

export default makeNumber;
