/**
 * Save in the variable 'minus' the result of
 * subtracting the variable 'a' from the variable 'b':
 * a - b
 */
function subtract() {
  let a = 20;
  let b = 10;
  let minus;

  // Add your code here

  // Don’t change this code
  return minus;
}

export default subtract;
