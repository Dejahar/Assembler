/**
 * Create a variable
 * named: myVar
 *
 * with the value of:
 * 'hello-world'
 */
function makeVar() {
  // Write your code here

  // Don’t change this code
  return myVar;
}

export default makeVar;
