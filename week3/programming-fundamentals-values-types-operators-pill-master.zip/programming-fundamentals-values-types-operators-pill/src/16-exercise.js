/**
 * Store in the variable result the person named 'James'
 *
 * NOTE:
 * You will have to copy the value from the 'tenants' array
 * into the variable 'result' by accessing it’s exact position.
 *
 * @example
 * result = data[2][2]
 */
function twoDimensionalArray() {
  let tenants = [
    ["Ana", "Alex", "Andrian", "Max", "Miguel"],
    ["James", "John", "Robert", "William", "David"]
  ];
  let result;

  // Add your code here

  // Don’t change this code
  return result;
}

export default twoDimensionalArray;
