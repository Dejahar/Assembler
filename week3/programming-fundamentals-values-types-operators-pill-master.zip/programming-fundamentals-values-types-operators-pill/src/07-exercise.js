/**
 * Save in the variable 'sum'
 * the result of:
 * adding the variable 'a' to the variable 'b'
 *
 * a + b
 */
function add() {
  let a = 20;
  let b = 10;
  let sum;

  // Add your code here

  // Don’t change this code
  return sum;
}

export default add;
