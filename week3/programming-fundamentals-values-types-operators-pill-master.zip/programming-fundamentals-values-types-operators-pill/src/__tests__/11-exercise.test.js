import getTotal from "../11-exercise";

test("exercise 11: saves the result of a % 5 + 10 * 2 in variable total", () => {
  expect(getTotal()).toBe(22);
});
