import getArrLength from "../14-exercise";

test("exercise 14: save in the variable result the length of the numbers array", () => {
  expect(getArrLength()).toBe(10);
});
