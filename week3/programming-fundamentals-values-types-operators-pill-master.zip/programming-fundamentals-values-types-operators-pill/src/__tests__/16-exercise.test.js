import twoDimensionalArray from "../16-exercise";

test("exercise 16: saves in the variable 'result' the name of James from the 'tenants' array", () => {
  expect(twoDimensionalArray()).toBe("James");
});
