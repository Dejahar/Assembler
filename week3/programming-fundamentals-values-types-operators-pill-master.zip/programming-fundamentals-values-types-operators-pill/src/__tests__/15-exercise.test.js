import changeValueInArray from "../15-exercise";

test("exercise 15: change the value in position 3 of the 'fruits' array to be 'kiwi'", () => {
  expect(changeValueInArray()[3]).toBe("kiwi");
});
