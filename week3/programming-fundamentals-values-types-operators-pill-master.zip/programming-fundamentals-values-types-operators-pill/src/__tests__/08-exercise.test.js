import subtract from "../08-exercise";

test("exercise 8: saves the result of a - b in variable minus", () => {
  expect(subtract()).toBe(10);
});
