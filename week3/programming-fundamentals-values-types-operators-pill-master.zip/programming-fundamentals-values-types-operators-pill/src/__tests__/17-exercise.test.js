import threeDimensionalArray from "../17-exercise";

test("exercise 17: saves in the variable 'result' the name of 'Adrian Mateo' from the 'fullnames' array", () => {
  expect(threeDimensionalArray()).toBe("Adrian Mateo");
});
