import add from "../07-exercise";

test("exercise 7: saves the result of a + b in variable sum", () => {
  expect(add()).toBe(30);
});
