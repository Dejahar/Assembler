import getValueInArray from "../13-exercise";

test("exercise 13: saves in the variable 'result' the value 'pear' from the 'fruits' array", () => {
  expect(getValueInArray()).toBe("pear");
});
