import divide from "../09-exercise";

test("exercise 9: saves the result of a / b in variable division", () => {
  expect(divide()).toBe(2);
});
