import multiply from "../10-exercise";

test("exercise 10: saves the result of a * b in variable multiplication", () => {
  expect(multiply()).toBe(200);
});
