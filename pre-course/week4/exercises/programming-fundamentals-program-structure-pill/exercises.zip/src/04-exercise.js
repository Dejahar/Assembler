/**
 * Correct the variable name so that it doesn’t use
 * a JavaScript reserved name.
 *
 * You can choose any valid name for the variable.
 */
function exercise04() {
    // Correct the variable name
    var anyVariable = 'fix my name';
}

module.exports = exercise04;
