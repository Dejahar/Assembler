/**
 * Update the function 'exercise05'
 * to return the sum of the 3 parameters
 * 'a', 'b' and 'c' that it receives
 */
function exercise05(a, b, c) {
    // Write your solution bellow this line
    let sum = a + b + c;
    return sum;
}

module.exports = exercise05;