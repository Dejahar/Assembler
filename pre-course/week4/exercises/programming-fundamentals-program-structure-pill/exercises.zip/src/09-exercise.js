/**
 * Create a for loop to console.log the numbers
 * from 0 to 9 (both 0 and 9 inclusive)
 * 0 -> 9
 */
function exercise09() {
    // Write your solution bellow this line
    for (let index = 0; index < 10; index++) {
        let number = index;
        console.log(number);
    }
}

module.exports = exercise09;
