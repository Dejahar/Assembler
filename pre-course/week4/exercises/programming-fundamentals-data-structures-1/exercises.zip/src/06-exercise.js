/**
 * Use the built in `shift()` method of arrays
 * to remove the first element from the `names` array.
 */
function exercise06() {
    const names = ['John', 'Mark', 'Ana'];

    // Write your solution bellow this line
    names.shift();
    // Don’t change the code bellow this line
    return names;
}

module.exports = exercise06;
