const exercise08 = require('../08-exercise');

describe('08-exercise', () => {
    test('use `array.find()` to find the city "Berlin" and return it', () => {
        expect(exercise08()).toBe('Berlin');
    });
});
