/**
 * Complete the function bellow to:
 *
 * 1. return the result of calling the getSum function
 */

// Complete the code to this function
function exercise04() {
    return getSum();
}

// Don’t change the code bellow this line
function getSum() {
    return 40 + 60;
}

module.exports = exercise04;
