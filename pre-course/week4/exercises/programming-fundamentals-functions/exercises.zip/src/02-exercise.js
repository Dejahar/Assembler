/**
 * Complete the function bellow to:
 *
 * 1. receive 3 number parameters
 * 2. return their sum
 *
 * NOTE: You will have to add the parameters to the function
 */

// Complete the code to the function
function exercise02( a, b, c) {
    return a + b + c;
}

exercise02(1,2,3);

module.exports = exercise02;