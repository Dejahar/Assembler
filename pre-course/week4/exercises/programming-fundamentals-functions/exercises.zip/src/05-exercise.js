/**
 * Complete the function bellow to return the result of:
 *
 * calling the getSum() function
 * added to the result of
 * calling the getMul() function
 */

// Complete the code to this function
function exercise05() {
    return getMul() + getSum();
}

// Don’t change the code bellow this line
function getSum() {
    return 40 + 60;
}

function getMul() {
    return 4 * 4;
}

module.exports = exercise05;
