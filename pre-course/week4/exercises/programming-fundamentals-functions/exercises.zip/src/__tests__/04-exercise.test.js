const exercise04 = require('../04-exercise');

describe('04-exercise', () => {
    test('return the result of calling the getSum function', () => {
        expect(exercise04()).toBe(100);
    });
});
