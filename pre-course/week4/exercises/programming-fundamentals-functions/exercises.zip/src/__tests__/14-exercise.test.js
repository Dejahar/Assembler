const exercise14 = require('../14-exercise');

describe('14-exercise', () => {
    test('return the total of the ingresos array minus the total of the gastos array', () => {
        expect(exercise14()).toBe(-50);
    });
});
