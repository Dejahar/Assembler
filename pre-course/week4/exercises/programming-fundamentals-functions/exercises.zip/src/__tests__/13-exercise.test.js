const exercise13 = require('../13-exercise');

describe('13-exercise', () => {
    test('return the amount of 1s in the nums multidimensional array', () => {
        expect(exercise13()).toBe(6);
    });
});
