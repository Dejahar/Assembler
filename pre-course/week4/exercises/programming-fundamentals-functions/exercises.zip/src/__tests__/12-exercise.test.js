const exercise12 = require('../12-exercise');

describe('12-exercise', () => {
    test('return the amount of 1s in the array', () => {
        expect(exercise12()).toBe(4);
    });
});
