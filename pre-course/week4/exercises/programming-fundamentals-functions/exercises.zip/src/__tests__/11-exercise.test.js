const exercise11 = require('../11-exercise');

describe('11-exercise', () => {
    test('return the sum of all the odd numbers in the array', () => {
        expect(exercise11()).toBe(22);
    });
});
