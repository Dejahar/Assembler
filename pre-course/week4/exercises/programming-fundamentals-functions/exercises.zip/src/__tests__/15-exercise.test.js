const exercise15 = require('../15-exercise');

describe('15-exercise', () => {
    test('return the sum of the negative nums in the nums array', () => {
        expect(exercise15()).toBe(-40);
    });
});
